#!/usr/bin/env python3
"""
build_workbook.py — Turn an extraction JSON (following the schema in
references/extraction-schema.md) into a formatted Excel workbook with
a Data sheet and a Sources sheet, cross-linked by a row ID.

Usage:
    python3 build_workbook.py <extraction.json> <output.xlsx>

Input JSON shape:
{
  "document": "City of Example FY2025 Adopted Budget",
  "items": [
    {
      "id": 1,
      "line_item": "General Fund - Total Revenue",
      "value": 1234567,
      "unit": "actual_dollars",   // or "thousands", "millions"
      "fiscal_year": "FY2025",
      "period": "adopted",         // adopted | proposed | actual | estimated
      "fund_or_category": "General Fund",
      "page": 42,
      "table_or_section": "Table 3: Revenue Summary",
      "notes": "Excludes one-time ARPA transfer of $8.1M",
      "confidence": "high"         // high | medium (ocr-sourced) | low (unclear)
    }
  ]
}

Why a script and not just "make an Excel doc": the formatting (frozen
header, number formats by unit, confidence color-coding, sources sheet
with clickable-feeling page refs) is deterministic and repetitive across
every financial-PDF job — better to do it the same correct way every
time than freehand it per document.
"""
import sys
import json
import argparse
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

CONFIDENCE_FILLS = {
    "low": PatternFill("solid", fgColor="FFF3CD"),
    "medium": PatternFill("solid", fgColor="FFF9E6"),
    "high": None,
}

HEADER_FILL = PatternFill("solid", fgColor="1F3864")
HEADER_FONT = Font(color="FFFFFF", bold=True)


def build(extraction_path, output_path):
    with open(extraction_path) as f:
        data = json.load(f)

    items = data.get("items", [])
    doc_name = data.get("document", "Untitled document")

    wb = Workbook()
    ws = wb.active
    ws.title = "Data"

    headers = [
        "ID", "Line item", "Value", "Unit", "Fiscal year", "Period",
        "Fund / category", "Notes", "Confidence", "Source page",
    ]
    ws.append(headers)
    for col_idx, _ in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col_idx)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
    ws.freeze_panes = "A2"

    for item in items:
        row = [
            item.get("id"),
            item.get("line_item"),
            item.get("value"),
            item.get("unit"),
            item.get("fiscal_year"),
            item.get("period"),
            item.get("fund_or_category"),
            item.get("notes"),
            item.get("confidence", "high"),
            item.get("page"),
        ]
        ws.append(row)
        r = ws.max_row
        fill = CONFIDENCE_FILLS.get(item.get("confidence", "high"))
        if fill:
            for col_idx in range(1, len(headers) + 1):
                ws.cell(row=r, column=col_idx).fill = fill
        # Number formatting by unit
        value_cell = ws.cell(row=r, column=3)
        unit = item.get("unit", "")
        if unit == "thousands":
            value_cell.number_format = '#,##0,"K"'
        elif unit == "millions":
            value_cell.number_format = '#,##0.0,,"M"'
        else:
            value_cell.number_format = "#,##0"

    for i, header in enumerate(headers, start=1):
        ws.column_dimensions[get_column_letter(i)].width = max(14, len(header) + 4)
    ws.column_dimensions["B"].width = 40
    ws.column_dimensions["H"].width = 45

    # Sources / provenance sheet
    ws2 = wb.create_sheet("Sources")
    ws2.append(["Document", doc_name])
    ws2.append([])
    ws2.append(["ID", "Line item", "Page", "Table / section", "Confidence"])
    for col_idx in range(1, 6):
        cell = ws2.cell(row=3, column=col_idx)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
    for item in items:
        ws2.append([
            item.get("id"),
            item.get("line_item"),
            item.get("page"),
            item.get("table_or_section", ""),
            item.get("confidence", "high"),
        ])
    for i in range(1, 6):
        ws2.column_dimensions[get_column_letter(i)].width = 22
    ws2.column_dimensions["B"].width = 40
    ws2.column_dimensions["D"].width = 35

    wb.save(output_path)
    print(f"Wrote {len(items)} line items to {output_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("extraction_json")
    parser.add_argument("output_xlsx")
    args = parser.parse_args()
    build(args.extraction_json, args.output_xlsx)
