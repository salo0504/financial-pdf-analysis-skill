#!/usr/bin/env python3
"""
extract_pdf.py — Page-tagged text + table extraction for financial PDFs,
with automatic OCR fallback for scanned pages.

Usage:
    python3 extract_pdf.py <input.pdf> <output_dir> [--dpi 300] [--ocr-threshold 20]

Output (written to output_dir):
    pages.json    — one entry per page: {page, method, text, char_count}
    tables.json   — one entry per detected table: {page, table_index, rows}
    manifest.json — summary: page count, pages needing OCR, low-confidence pages

Why this exists: the pdf-reading skill covers the mechanics (pdftotext,
pdfplumber, pytesseract) but doing this page-by-page, deciding text-vs-OCR
per page, and keeping everything tagged with a page number so every later
citation is traceable, is repetitive and error-prone to do by hand across
a 100+ page CAFR. This script does that triage once, deterministically.

Pages that fall back to OCR are flagged with "method": "ocr" — treat any
figure sourced from an OCR'd page as lower-confidence and worth a second
look (OCR misreads digits, especially in dense tables).
"""
import sys
import json
import argparse
import os


def extract(input_pdf, output_dir, dpi=300, ocr_threshold=20, start_page=None, end_page=None):
    import pdfplumber
    import pytesseract
    from pdf2image import convert_from_path

    os.makedirs(output_dir, exist_ok=True)

    pages_out = []
    tables_out = []
    ocr_pages = []

    with pdfplumber.open(input_pdf) as pdf:
        n_pages = len(pdf.pages)
        lo = (start_page - 1) if start_page else 0
        hi = end_page if end_page else n_pages
        for i in range(lo, hi):
            page = pdf.pages[i]
            page_num = i + 1
            text = page.extract_text() or ""
            char_count = len(text.strip())
            method = "text"

            if char_count < ocr_threshold:
                # Likely scanned or image-only page — fall back to OCR
                method = "ocr"
                ocr_pages.append(page_num)
                try:
                    images = convert_from_path(
                        input_pdf, dpi=dpi, first_page=page_num, last_page=page_num
                    )
                    text = pytesseract.image_to_string(images[0]) if images else ""
                except Exception as e:
                    text = f"[OCR FAILED: {e}]"

            pages_out.append(
                {
                    "page": page_num,
                    "method": method,
                    "char_count": len(text.strip()),
                    "text": text,
                }
            )

            # Table extraction (pdfplumber's built-in detector; good for
            # ruled/bordered tables — see references/extraction-schema.md
            # for when to fall back to camelot for borderless tables)
            try:
                tables = page.extract_tables()
            except Exception:
                tables = []
            for t_idx, table in enumerate(tables):
                if table and any(any(cell for cell in row) for row in table):
                    tables_out.append(
                        {"page": page_num, "table_index": t_idx, "rows": table}
                    )

            print(f"  page {page_num}/{n_pages}: {method}, {len(text.strip())} chars, "
                  f"{len(tables)} table(s)", file=sys.stderr)

    pages_path = os.path.join(output_dir, "pages.json")
    tables_path = os.path.join(output_dir, "tables.json")
    manifest_path = os.path.join(output_dir, "manifest.json")

    existing_pages = []
    existing_tables = []
    if os.path.exists(pages_path):
        with open(pages_path) as f:
            existing_pages = json.load(f)
    if os.path.exists(tables_path):
        with open(tables_path) as f:
            existing_tables = json.load(f)

    all_pages = {p["page"]: p for p in existing_pages}
    for p in pages_out:
        all_pages[p["page"]] = p
    merged_pages = [all_pages[k] for k in sorted(all_pages)]

    existing_tables = [t for t in existing_tables if not (lo + 1 <= t["page"] <= hi)]
    merged_tables = existing_tables + tables_out

    with open(pages_path, "w") as f:
        json.dump(merged_pages, f, indent=2)

    with open(tables_path, "w") as f:
        json.dump(merged_tables, f, indent=2)

    all_ocr_pages = sorted(set(
        [p["page"] for p in merged_pages if p["method"] == "ocr"]
    ))
    manifest = {
        "source_file": os.path.basename(input_pdf),
        "page_count": n_pages,
        "pages_processed": len(merged_pages),
        "ocr_pages": all_ocr_pages,
        "ocr_page_count": len(all_ocr_pages),
        "tables_detected": len(merged_tables),
    }
    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)

    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("input_pdf")
    parser.add_argument("output_dir")
    parser.add_argument("--dpi", type=int, default=300)
    parser.add_argument("--ocr-threshold", type=int, default=20,
                         help="Pages with fewer extracted chars than this trigger OCR fallback")
    parser.add_argument("--start-page", type=int, default=None,
                         help="1-indexed first page to process (for batching large PDFs)")
    parser.add_argument("--end-page", type=int, default=None,
                         help="1-indexed last page to process, inclusive (for batching large PDFs)")
    args = parser.parse_args()
    extract(args.input_pdf, args.output_dir, args.dpi, args.ocr_threshold,
            args.start_page, args.end_page)
